import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environment/environment';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-profile',
  standalone: true,
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
  imports: [CommonModule]
})
export class ProfileComponent implements OnInit {
  user: any = {};
  posts: any[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    const token = localStorage.getItem('token');
    if (!token) return;

    // Get user profile
    this.http.get(`${environment.apiUrl}/auth/me`, {
      headers: { Authorization: `Bearer ${token}` }
    }).subscribe({
      next: (res: any) => {
        this.user = res;
        this.loadUserPosts(res.id);
      },
      error: (err) => {
        console.error('Failed to load user info:', err);
      }
    });
  }

  loadUserPosts(userId: number): void {
    this.http.get<any[]>(`${environment.apiUrl}/posts/user/${userId}`).subscribe({
      next: (posts) => this.posts = posts,
      error: (err) => console.error('Failed to load posts:', err)
    });
  }
}
